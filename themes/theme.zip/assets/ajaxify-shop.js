/**
 * ThreadSketch Ajax Cart
 * Premium shopping experience
 *
 * @author ThreadSketch
 * @version 1.0
 */

var Shopify = Shopify || {}

Shopify.addItem = (variant_id, quantity, callback) => {
  quantity = quantity || 1

  var params = {
    type: "POST",
    url: "/cart/add.js",
    data: "quantity=" + quantity + "&id=" + variant_id,
    dataType: "json",
    success: (line_item) => {
      if (typeof callback === "function") {
        callback(line_item)
      } else {
        Shopify.onItemAdded(line_item)
      }
    },
    error: (XMLHttpRequest, textStatus) => {
      Shopify.onError(XMLHttpRequest, textStatus)
    },
  }

  jQuery.ajax(params)
}

Shopify.onItemAdded = (line_item) => {
  // Remove the alert('Product Added to Cart');
  // Add a more subtle notification or let the cart update handle it
  // Example:
  // console.log('Product added to cart:', line_item);
}

Shopify.onError = (XMLHttpRequest, textStatus) => {
  var feedback = ""
  if (XMLHttpRequest.responseJSON && XMLHttpRequest.responseJSON.description) {
    feedback = XMLHttpRequest.responseJSON.description
  } else {
    feedback = "Error : " + textStatus
  }
  console.error(feedback)
}
