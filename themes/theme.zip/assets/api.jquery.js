// ThreadSketch Cart API Extensions
// Based on Shopify's Cart API with custom modifications

/**
 * ThreadSketch Modifications:
 * - Enhanced form handling for smoother cart updates
 * - Improved error handling for better UX
 */

if (typeof Shopify === "undefined") {
  Shopify = {}
}

Shopify.money_format = "${{amount}}"

Shopify.formatMoney = function (cents, format) {
  if (typeof cents == "string") {
    cents = cents.replace(".", "")
  }
  var value = ""
  var placeholderRegex = /\{\{\s*(\w+)\s*\}\}/,
    formatString = format || this.money_format

  function defaultOption(opt, def) {
    return typeof opt == "undefined" ? def : opt
  }

  function formatWithDelimiters(number, precision, thousands, decimal) {
    precision = defaultOption(precision, 2)
    thousands = defaultOption(thousands, ",")
    decimal = defaultOption(decimal, ".")

    if (isNaN(precision) || precision == null) {
      precision = 2
    }

    var number = number.toFixed(precision),
      parts = number.split(".")
    var dollars = parts[0].replace(/(\d)(?=(\d\d\d)+$)/g, "$1" + thousands)
    var cents = parts[1] ? decimal + parts[1] : ""

    return dollars + cents
  }

  switch (formatString.match(placeholderRegex)[1]) {
    case "amount":
      value = formatWithDelimiters(cents / 100.0, 2)
      break
    case "amount_no_decimals":
      value = formatWithDelimiters(cents / 100.0, 0)
      break
    case "amount_with_comma_separator":
      value = formatWithDelimiters(cents / 100.0, 2, ".", ",")
      break
    case "amount_no_decimals_with_comma_separator":
      value = formatWithDelimiters(cents / 100.0, 0, ".", ",")
      break
  }

  return formatString.replace(placeholderRegex, value)
}

Shopify.onError = (XMLHttpRequest, textStatus) => {
  // Shopify returns a description of the error in the 'description' property of the response.
  // It is wrapped in a comment tag, so we need to strip that off.
  var feedback = ""
  try {
    feedback = eval("(" + XMLHttpRequest.responseText + ")").description
  } catch (e) {
    feedback =
      "Error : " + Shopify.fullMessagesFromErrors(eval("(" + XMLHttpRequest.responseText + ")")).join("; ") + "."
  }
  if (feedback == "") {
    feedback = "Error : " + textStatus + "."
  }
  alert(feedback)
}

Shopify.fullMessagesFromErrors = (errors) => {
  var fullMessages = []
  jQuery.each(errors, (attribute, messages) => {
    jQuery.each(messages, (index, message) => {
      fullMessages.push(attribute + " " + message)
    })
  })
  return fullMessages
}

Shopify.onCartUpdate = (cart) => {
  alert("There are now " + cart.item_count + " items in the cart.")
}

Shopify.onCartShippingRatesUpdate = (shipping_rates) => {
  var shippingRates = shipping_rates.shipping_rates
  alert("There are " + shippingRates.length + " shipping rates available.")
  if (shippingRates.length) {
    alert(
      "The first one is " +
        Shopify.formatMoney(shippingRates[0].price, "${{amount_with_comma_separator}}") +
        " " +
        shippingRates[0].name,
    )
  }
}

Shopify.onItemAdded = (line_item) => {
  alert(line_item.title + " was successfully added to your cart.")
}

Shopify.onProduct = (product) => {
  alert("The product's title is " + product.title + ".")
}

Shopify.showModal = (selector) => {
  jQuery(selector).modal()
}

Shopify.hideModal = (selector) => {
  jQuery(selector).modal("hide")
}

Shopify.getProduct = (handle, callback) => {
  jQuery.ajax({
    type: "GET",
    url: "/products/" + handle + ".js",
    dataType: "json",
    success: (product) => {
      if (typeof callback === "function") {
        callback(product)
      } else {
        Shopify.onProduct(product)
      }
    },
  })
}

Shopify.addItem = (variant_id, quantity, callback) => {
  var quantity = quantity || 1
  var params = {
    type: "POST",
    url: "/cart/add.js",
    data: "quantity=" + quantity + "&id=" + variant_id,
    dataType: "json",
    success: (line_item) => {
      if (typeof callback === "function") {
        callback(line_item)
      } else {
        Shopify.onItemAdded(line_item)
      }
    },
    error: (XMLHttpRequest, textStatus) => {
      Shopify.onError(XMLHttpRequest, textStatus)
    },
  }
  jQuery.ajax(params)
}

Shopify.getCart = (callback) => {
  jQuery.ajax({
    type: "GET",
    url: "/cart.js",
    dataType: "json",
    success: (cart) => {
      if (typeof callback === "function") {
        callback(cart)
      } else {
        Shopify.onCartUpdate(cart)
      }
    },
    error: (XMLHttpRequest, textStatus) => {
      Shopify.onError(XMLHttpRequest, textStatus)
    },
  })
}

Shopify.clearCart = (callback) => {
  jQuery.ajax({
    type: "POST",
    url: "/cart/clear.js",
    success: (cart) => {
      if (typeof callback === "function") {
        callback(cart)
      } else {
        Shopify.onCartUpdate(cart)
      }
    },
    error: (XMLHttpRequest, textStatus) => {
      Shopify.onError(XMLHttpRequest, textStatus)
    },
  })
}

Shopify.removeItem = (id, callback) => {
  jQuery.ajax({
    type: "POST",
    url: "/cart/change.js",
    data: "quantity=0&id=" + id,
    dataType: "json",
    success: (cart) => {
      if (typeof callback === "function") {
        callback(cart)
      } else {
        Shopify.onCartUpdate(cart)
      }
    },
    error: (XMLHttpRequest, textStatus) => {
      Shopify.onError(XMLHttpRequest, textStatus)
    },
  })
}

Shopify.changeItem = (id, quantity, callback) => {
  jQuery.ajax({
    type: "POST",
    url: "/cart/change.js",
    data: "quantity=" + quantity + "&id=" + id,
    dataType: "json",
    success: (cart) => {
      if (typeof callback === "function") {
        callback(cart)
      } else {
        Shopify.onCartUpdate(cart)
      }
    },
    error: (XMLHttpRequest, textStatus) => {
      Shopify.onError(XMLHttpRequest, textStatus)
    },
  })
}

Shopify.getCartShippingRatesForDestination = (shipping_address, callback, errorCallback) => {
  var params = {
    type: "POST",
    url: "/cart/shipping_rates.js",
    data: Shopify.param(shipping_address),
    dataType: "json",
    success: (shipping_rates) => {
      if (typeof callback === "function") {
        callback(shipping_rates)
      } else {
        Shopify.onCartShippingRatesUpdate(shipping_rates)
      }
    },
    error:
      typeof errorCallback === "function"
        ? errorCallback
        : (XMLHttpRequest, textStatus) => {
            Shopify.onError(XMLHttpRequest, textStatus)
          },
  }
  jQuery.ajax(params)
}

Shopify.param = (a) => {
  var s = []
  var add = (key, value) => {
    // If value is a function, invoke it and return its value
    value = jQuery.isFunction(value) ? value() : value

    s[s.length] = encodeURIComponent(key) + "=" + encodeURIComponent(value)
  }

  var buildParams = (prefix, obj) => {
    var i, len, key

    if (prefix) {
      if (jQuery.isArray(obj)) {
        for (i = 0, len = obj.length; i < len; i++) {
          buildParams(prefix + "[" + (typeof obj[i] === "object" ? i : "") + "]", obj[i])
        }
      } else if (jQuery.type(obj) === "object") {
        // Serialize Object
        for (key in obj) {
          buildParams(prefix + "[" + key + "]", obj[key])
        }
      } else {
        // Serialize scalar item
        add(prefix, obj)
      }
    } else {
      // Serialize array item or object
      if (jQuery.isArray(obj)) {
        for (i = 0, len = obj.length; i < len; i++) {
          add(obj[i].name, obj[i].value)
        }
      } else {
        for (key in obj) {
          buildParams(key, obj[key])
        }
      }
    }
    return s
  }

  return buildParams("", a).join("&").replace(/%20/g, "+")
}

// Enhanced form submission for cart updates
jQuery(document).on("submit", 'form[action="/cart/add"]', function (e) {
  e.preventDefault()
  var $form = jQuery(this)
  var formData = $form.serialize()

  jQuery.ajax({
    type: "POST",
    url: "/cart/add.js",
    data: formData,
    dataType: "json",
    success: (line_item) => {
      Shopify.getCart((cart) => {
        Shopify.onCartUpdate(cart) // Trigger cart update event
        // Optionally, update cart display here
      })
    },
    error: (XMLHttpRequest, textStatus) => {
      Shopify.onError(XMLHttpRequest, textStatus)
    },
  })
})

jQuery(document).on("submit", 'form[action="/cart/update"]', function (e) {
  e.preventDefault()
  var $form = jQuery(this)
  var formData = $form.serialize()

  jQuery.ajax({
    type: "POST",
    url: "/cart/update.js",
    data: formData,
    dataType: "json",
    success: (cart) => {
      Shopify.getCart((cart) => {
        Shopify.onCartUpdate(cart) // Trigger cart update event
        // Optionally, update cart display here
      })
    },
    error: (XMLHttpRequest, textStatus) => {
      Shopify.onError(XMLHttpRequest, textStatus)
    },
  })
})
